Group Number  --> 23
Names and IDs --> 1. Garvit Soni		    2017B3A70458H
		  2. Aman Badjate   		    2017B3A70559H
		  3. Prakhar Suryavansh             2017B4A71017H

Run the following command to compile and run the code:

1. On Windows: gcc lexer.c driver.c -o k
	       k <filename>

2. On Linux: gcc lexer.c driver.c -o k
	     ./k <filename>